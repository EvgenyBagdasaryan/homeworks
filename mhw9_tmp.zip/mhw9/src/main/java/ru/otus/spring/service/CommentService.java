package ru.otus.spring.service;

public interface CommentService {
}
