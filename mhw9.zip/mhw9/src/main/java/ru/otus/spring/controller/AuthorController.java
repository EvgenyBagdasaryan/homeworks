package ru.otus.spring.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import ru.otus.spring.domain.Author;
import ru.otus.spring.domain.Book;
import ru.otus.spring.service.AuthorService;
import ru.otus.spring.exceptions.DocumentNotFoundException;

import java.util.List;

@Controller
public class AuthorController {

    private final AuthorService authorService;

    @Autowired
    public AuthorController(AuthorService authorService) {
        this.authorService = authorService;
    }

    @GetMapping("/authors")
    public String listPage(@RequestParam("bookId") String bookId, Model model) {

        List<Author> authors = authorService.getAuthorsByBookId(bookId);
        model.addAttribute("authors", authors);
        model.addAttribute("bookId", bookId);
        return "list_of_authors";
    }

    @GetMapping("/author")
    public String editAuthor(@RequestParam String bookId, @RequestParam("id") String id, Model model) throws DocumentNotFoundException {
        Author author = authorService.getAuthorById(id);//.orElseThrow(DocumentNotFoundException::new);
        model.addAttribute("author", author);
        model.addAttribute("bookId", bookId);
        return "author";
    }

    @PostMapping("/author")
    public String updateAuthor(@RequestParam String bookId, String name, Model model) {
        //authorService.updateAuthor(bookId, new Author(null, name));
        authorService.saveAuthor(bookId, new Author(null, name));
        return String.format("redirect:/authors?bookId=%s", bookId);
    }
}