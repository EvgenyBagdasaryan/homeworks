package ru.otus.spring.service;

public interface GenreService {
}
